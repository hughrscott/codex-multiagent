# codex-mcp-remote (HTTP transport)

A minimal Remote MCP server over HTTP. Serves a manifest at `/.well-known/mcp/manifest.json`
and accepts JSON-RPC style tool calls at `POST /mcp`.

## Run
```
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python server.py
```
